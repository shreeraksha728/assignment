import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB, GaussianNB
from sklearn import svm
from sklearn.model_selection import GridSearchCV

##Step1: Load Dataset

##Step2: Split in to Training and Test Data

##Step3: Extract Features

##Step4: Build a model

##Step5: Test Accuracy




